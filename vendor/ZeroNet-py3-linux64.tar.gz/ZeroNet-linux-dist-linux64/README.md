# ZeroNet-linux
ZeroNet bundle for Linux

Start using `./ZeroNet.sh`
